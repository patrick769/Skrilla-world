import { useEffect, useState } from 'react';
import {
  ArrowRight, CalendarDays, MapPin, Menu, Music2, Package,
  Play, ShoppingBag, Ticket, Video, X
} from 'lucide-react';
import { ShatterSphere } from './components/ShatterSphere';
import backgroundImage from './assets/background.jpg';
import cover1 from './assets/cover1.jpg';
import cover2 from './assets/cover2.jpg';
import cover3 from './assets/cover3.jpg';

type PageName = 'home' | 'music' | 'videos' | 'tour' | 'merch';

const NAV_LINKS: { id: PageName; label: string; href: string }[] = [
  { id: 'home', label: 'HOME', href: './index.html' },
  { id: 'music', label: 'MUSIC', href: './music.html' },
  { id: 'videos', label: 'VIDEOS', href: './videos.html' },
  { id: 'tour', label: 'TOUR', href: './tour.html' },
  { id: 'merch', label: 'MERCH', href: './merch.html' }
];

const DROPS = [
  { cover: cover1, title: 'PRAISE YOU (SKRILLA FLIP)', tag: 'SINGLE • 2026' },
  { cover: cover2, title: 'QUANTUM OVERDRIVE', tag: 'ALBUM • 2025' },
  { cover: cover3, title: 'NIGHT DRIVE 2099', tag: 'EP • 2025' }
];

const TOUR = [
  { date: 'MAR 14', city: 'ATLANTA, GA', venue: 'State Farm Arena' },
  { date: 'MAR 21', city: 'HOUSTON, TX', venue: 'Toyota Center' },
  { date: 'APR 02', city: 'LOS ANGELES, CA', venue: 'Crypto.com Arena' },
  { date: 'APR 18', city: 'NEW YORK, NY', venue: 'Barclays Center' },
  { date: 'MAY 09', city: 'LONDON, UK', venue: 'The O2' }
];

const VIDEOS = [
  { image: cover2, title: '#itriedcallingyou', meta: 'OFFICIAL VIDEO • 4:18' },
  { image: cover1, title: 'PRAISE YOU', meta: 'VISUALIZER • 3:42' },
  { image: cover3, title: 'NIGHT DRIVE 2099', meta: 'LIVE SESSION • 5:06' }
];

const MERCH = [
  { name: '#itriedcallingyou TOUR JACKET', price: '$120', mark: 'WORLD TOUR 2026' },
  { name: 'QUANTUM CORE HOODIE', price: '$85', mark: 'BIG SKRILLA' },
  { name: 'NOIR SIGNAL TEE', price: '$45', mark: 'EST. 2099' }
];

const SPOTIFY_URL = 'https://open.spotify.com/artist/0jdv3ikqQ1AH0RWhgq5gPl';

const SOCIAL_LINKS = [
  { label: 'SPOTIFY', href: SPOTIFY_URL },
  { label: 'YOUTUBE', href: 'https://www.youtube.com/@jeshiyadago7380' },
  { label: 'INSTAGRAM', href: 'https://www.instagram.com/_skrillagram/' },
  { label: 'FACEBOOK', href: 'https://www.facebook.com/prince.j.sinclair' },
  { label: 'WHATSAPP', href: 'https://wa.me/254703200940' },
  { label: 'TIKTOK', href: 'https://www.tiktok.com/@sinclairkahara?_r=1&_t=ZS-9965ZLGKel5' }
];

const TriangleMark = ({ size = 44, className = '' }: { size?: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" className={className} fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
    <path d="M8 14 L92 38 L30 92 Z" />
    <path d="M50 26 L61 62 L19 53 Z" />
    <path d="M29 20 L34 38 L13 33 Z" />
    <path d="M71 32 L76 50 L55 44 Z" />
    <path d="M40 58 L45 76 L24 71 Z" />
  </svg>
);

const DotArc = ({ className = '' }: { className?: string }) => (
  <svg viewBox="0 0 400 400" className={className} fill="none" aria-hidden="true">
    <circle cx="200" cy="200" r="180" stroke="#1e5a63" strokeWidth="1.5" strokeDasharray="2 10" className="dash-anim" />
    <circle cx="200" cy="200" r="150" stroke="#17434a" strokeWidth="1" strokeDasharray="1 14" />
    <circle cx="200" cy="200" r="120" stroke="#1e5a63" strokeWidth="1" strokeDasharray="30 24" opacity="0.5" />
  </svg>
);

function GameLoader() {
  const [progress, setProgress] = useState(0);
  const [exiting, setExiting] = useState(false);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const started = performance.now();
    const duration = 2600;
    const timer = window.setInterval(() => {
      const elapsed = performance.now() - started;
      const ratio = Math.min(elapsed / duration, 1);
      // Fast opening, deliberate final lock — like a racing-game boot sequence.
      const eased = ratio < 0.82 ? ratio * 1.12 : 0.92 + ((ratio - 0.82) / 0.18) * 0.08;
      setProgress(Math.min(100, Math.floor(eased * 100)));
      if (ratio >= 1) {
        window.clearInterval(timer);
        setProgress(100);
        setExiting(true);
        window.setTimeout(() => setVisible(false), 520);
      }
    }, 45);
    return () => window.clearInterval(timer);
  }, []);

  if (!visible) return null;

  return (
    <div className={`game-loader fixed inset-0 z-[9999] overflow-hidden bg-[#050507] text-white ${exiting ? 'game-loader-exit' : ''}`} role="status" aria-label={`Loading ${progress}%`}>
      <div className="game-loader-grid absolute inset-0" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_45%,rgba(217,67,92,.22),transparent_38%)]" />
      <div className="speed-streak speed-streak-one" />
      <div className="speed-streak speed-streak-two" />
      <div className="speed-streak speed-streak-three" />

      <div className="relative flex h-full flex-col justify-between px-6 py-8 sm:px-12 sm:py-10">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <TriangleMark size={38} className="text-[#d9435c]" />
            <div>
              <div className="font-display text-sm font-black tracking-[0.25em] sm:text-base">BIG SKRILLA WORLD</div>
              <div className="font-tech mt-1 text-[9px] tracking-[0.34em] text-[#5c8a93]">SHADOW CORE ENGINE</div>
            </div>
          </div>
          <div className="font-tech text-[9px] tracking-[0.25em] text-white/30">BUILD // 2099.06</div>
        </div>

        <div className="mx-auto w-full max-w-4xl">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <div className="font-tech text-[10px] tracking-[0.4em] text-[#5c8a93]">INITIALIZING WORLD</div>
              <div className="font-display mt-2 text-3xl font-black italic tracking-tight sm:text-5xl">LOADING <span className="text-[#d9435c] text-glow-red">#itriedcallingyou</span></div>
            </div>
            <div className="font-display text-3xl font-black tabular-nums sm:text-5xl">{progress.toString().padStart(3, '0')}<span className="text-lg text-[#d9435c]">%</span></div>
          </div>
          <div className="relative h-2 overflow-hidden bg-white/10 skew-x-[-18deg]">
            <div className="h-full bg-gradient-to-r from-[#6f1f31] via-[#d9435c] to-white transition-[width] duration-75" style={{ width: `${progress}%` }} />
            <div className="loader-bar-shine absolute inset-y-0 w-28 bg-gradient-to-r from-transparent via-white/80 to-transparent" />
          </div>
          <div className="font-tech mt-4 flex flex-wrap justify-between gap-2 text-[9px] tracking-[0.28em] text-white/35">
            <span>VELOCITY SYSTEM // ONLINE</span>
            <span>AUDIO CORE // SYNCED</span>
            <span>WORLD STREAM // {progress < 100 ? 'CONNECTING' : 'READY'}</span>
          </div>
        </div>

        <div className="font-tech flex items-end justify-between text-[9px] tracking-[0.22em] text-white/25">
          <span>DO NOT CLOSE THE WINDOW</span>
          <span className="loader-pulse text-[#d9435c]">● LIVE SIGNAL</span>
        </div>
      </div>
    </div>
  );
}

function Header({ page }: { page: PageName }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`fixed inset-x-0 top-0 z-50 border-b transition-all duration-300 ${scrolled ? 'border-white/10 bg-[#050507]/95 py-3 backdrop-blur-md' : 'border-transparent bg-[#050507]/30 py-5 backdrop-blur-sm'}`}>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 md:px-8" aria-label="Main navigation">
        <a href="./index.html" className="group flex items-center gap-3">
          <TriangleMark size={40} className="text-white transition-colors group-hover:text-[#d9435c]" />
          <div className="leading-none">
            <span className="font-display block text-lg font-extrabold tracking-[0.18em]">BIG SKRILLA</span>
            <span className="font-tech text-[10px] tracking-[0.35em] text-[#5c8a93]">OFFICIAL WORLD</span>
          </div>
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map(link => (
            <li key={link.id}>
              <a href={link.href} aria-current={page === link.id ? 'page' : undefined} className={`font-tech relative py-2 text-sm tracking-[0.2em] transition-colors ${page === link.id ? 'text-white' : 'text-white/65 hover:text-white'}`}>
                {link.label}
                <span className={`absolute -bottom-0.5 left-0 h-[2px] bg-[#d9435c] transition-all duration-300 ${page === link.id ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </a>
            </li>
          ))}
        </ul>

        <a href={SPOTIFY_URL} target="_blank" rel="noopener noreferrer" className="hidden items-center gap-2 bg-[#d9435c] px-5 py-3 font-display text-xs font-bold tracking-[0.2em] text-white transition-all hover:bg-[#e85a71] hover:shadow-[0_0_25px_rgba(217,67,92,0.5)] md:inline-flex">
          <Play className="h-3.5 w-3.5 fill-current" /> LISTEN NOW
        </a>

        <button className="p-2 text-white md:hidden" onClick={() => setMenuOpen(v => !v)} aria-label="Toggle navigation" aria-expanded={menuOpen}>
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {menuOpen && (
        <div className="flex flex-col border-t border-white/10 bg-[#0a0a0e]/98 px-6 py-4 md:hidden">
          {NAV_LINKS.map(link => (
            <a key={link.id} href={link.href} className={`font-tech border-b border-white/5 py-3 tracking-[0.25em] ${page === link.id ? 'text-[#d9435c]' : 'text-white/80'}`}>
              {link.label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
}

function SmokeOverlay() {
  return (
    <div className="smoke-overlay pointer-events-none absolute inset-0 z-[1] overflow-hidden" aria-hidden="true">
      <i className="smoke-puff smoke-puff-1" />
      <i className="smoke-puff smoke-puff-2" />
      <i className="smoke-puff smoke-puff-3" />
      <i className="smoke-puff smoke-puff-4" />
      <i className="smoke-puff smoke-puff-5" />
      <i className="smoke-puff smoke-puff-6" />
    </div>
  );
}

function PageHero({ eyebrow, title, accent, description }: { eyebrow: string; title: string; accent: string; description: string }) {
  return (
    <section className="relative flex min-h-[58vh] items-end overflow-hidden border-b border-white/8 pt-32">
      <div className="absolute inset-0 bg-cover bg-[center_34%] opacity-40" style={{ backgroundImage: `url(${backgroundImage})` }} />
      <div className="absolute inset-0 bg-gradient-to-r from-[#050507] via-[#050507]/85 to-[#050507]/30" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#050507] via-[#050507]/20 to-[#050507]/80" />
      <SmokeOverlay />
      <DotArc className="absolute -right-36 -top-28 w-[520px] opacity-35" />
      <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 md:px-8 md:pb-20">
        <span className="font-tech text-xs tracking-[0.45em] text-[#5c8a93]">{eyebrow}</span>
        <h1 className="mt-3 max-w-4xl font-display text-4xl font-black tracking-wide sm:text-6xl md:text-7xl">
          {title} <span className="text-[#d9435c] text-glow-red">{accent}</span>
        </h1>
        <p className="mt-5 max-w-2xl text-lg leading-relaxed text-white/60">{description}</p>
      </div>
    </section>
  );
}

function HomePage() {
  return (
    <>
      <section className="relative flex min-h-screen items-center overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-[center_28%] md:bg-[center_30%]" style={{ backgroundImage: `url(${backgroundImage})` }} />
        <div className="absolute inset-0 bg-gradient-to-r from-[#050507] via-[#050507]/80 to-[#050507]/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050507] via-transparent to-[#050507]/70" />
        <SmokeOverlay />
        <DotArc className="absolute -top-40 left-1/4 hidden w-[480px] opacity-45 md:block" />
        <div className="relative z-10 mx-auto grid w-full max-w-7xl items-center gap-10 px-5 pb-16 pt-32 md:px-8 lg:grid-cols-2">
          <div>
            <div className="fade-up flex items-center gap-5">
              <TriangleMark size={72} className="shrink-0 text-white" />
              <div>
                <h1 className="font-display text-4xl font-black leading-none tracking-wide sm:text-5xl md:text-6xl">BIG<span className="text-[#d9435c] text-glow-red"> SKRILLA</span></h1>
                <p className="font-tech mt-2 text-xs tracking-[0.5em] text-[#5c8a93] sm:text-sm">EST. 2099 • STREET QUANTUM SOUND</p>
              </div>
            </div>
            <div className="fade-up fade-up-1 mt-9 inline-block -skew-x-3 bg-[#d9435c] px-6 py-4 shadow-[0_10px_40px_rgba(217,67,92,0.35)] sm:px-8">
              <span className="block skew-x-3 font-display text-lg font-bold tracking-wide sm:text-2xl">NEW ALBUM “#itriedcallingyou” OUT NOW</span>
            </div>
            <p className="fade-up fade-up-2 mt-7 max-w-md leading-relaxed text-white/60">Fourteen tracks recorded in the dark. Cigar smoke, velvet curtains and bass heavy enough to bend the room — the boss era begins here.</p>
            <div className="fade-up fade-up-3 mt-8 flex flex-wrap gap-4">
              <a href={SPOTIFY_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2.5 bg-white px-7 py-4 font-display text-sm font-bold tracking-widest text-black transition-colors hover:bg-[#d9435c] hover:text-white"><Play className="h-4 w-4 fill-current" /> STREAM THE ALBUM</a>
              <a href="./tour.html" className="inline-flex items-center gap-2.5 border border-white/30 px-7 py-4 font-display text-sm font-bold tracking-widest transition-colors hover:border-[#d9435c] hover:text-[#d9435c]">TOUR DATES <ArrowRight className="h-4 w-4" /></a>
            </div>
          </div>
          <div className="float-slow relative h-[340px] sm:h-[440px] lg:h-[520px]"><ShatterSphere /></div>
        </div>
      </section>
      <div className="overflow-hidden border-y border-black/30 bg-[#d9435c] py-3">
        <div className="ticker flex w-max whitespace-nowrap">{[0,1].map(k => <div key={k} className="flex">{Array.from({length:6},(_,i)=><span key={i} className="mx-6 flex items-center gap-6 font-display text-sm font-bold tracking-[0.3em]">BIG SKRILLA <b className="text-black">▲</b> #itriedcallingyou OUT NOW <b className="text-black">▲</b> WORLD TOUR 2026</span>)}</div>)}</div>
      </div>
      <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
        <div className="grid gap-6 md:grid-cols-3">
          {[['1.2B','GLOBAL STREAMS'],['14','NEW TRACKS'],['05','WORLD TOURS']].map(([n,l])=><a href="./music.html" key={l} className="border border-white/10 bg-white/[0.025] p-8 transition hover:border-[#d9435c]/60"><div className="font-display text-5xl font-black text-[#d9435c]">{n}</div><div className="font-tech mt-3 tracking-[0.3em] text-white/50">{l}</div></a>)}
        </div>
      </section>
    </>
  );
}

function MusicPage() {
  return <><PageHero eyebrow="DISCOGRAPHY // 001" title="LATEST" accent="DROPS" description="The complete transmission archive — singles, albums and late-night frequencies from Big Skrilla World." /><main className="mx-auto max-w-7xl px-5 py-20 md:px-8"><div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">{DROPS.map(d=><article key={d.title} className="group overflow-hidden border border-white/10 bg-[#0c0c10] transition hover:border-[#d9435c]/60"><div className="relative aspect-square overflow-hidden"><img src={d.cover} alt={d.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-105"/><div className="absolute inset-0 flex items-center justify-center bg-black/45 opacity-0 transition group-hover:opacity-100"><button aria-label={`Play ${d.title}`} className="flex h-16 w-16 items-center justify-center rounded-full bg-[#d9435c]"><Play className="h-6 w-6 fill-white"/></button></div></div><div className="flex items-center justify-between p-5"><div><h2 className="font-display text-sm font-bold tracking-wider">{d.title}</h2><p className="font-tech mt-1.5 text-[11px] tracking-[0.25em] text-[#5c8a93]">{d.tag}</p></div><Music2 className="h-5 w-5 text-[#d9435c]"/></div></article>)}</div></main></>;
}

function VideosPage() {
  return <><PageHero eyebrow="VISUAL ARCHIVE // 002" title="OFFICIAL" accent="VIDEOS" description="Enter the visual world: cinematic releases, live sessions and encrypted transmissions." /><main className="mx-auto max-w-7xl px-5 py-20 md:px-8"><div className="grid gap-7 md:grid-cols-2">{VIDEOS.map((v,i)=><article key={v.title} className={`group overflow-hidden border border-white/10 bg-[#0c0c10] transition hover:border-[#d9435c]/70 ${i===0?'md:col-span-2':''}`}><div className={`relative overflow-hidden ${i===0?'aspect-[16/7]':'aspect-video'}`}><img src={v.image} alt="" className="h-full w-full object-cover opacity-65 transition duration-700 group-hover:scale-105 group-hover:opacity-85"/><div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"/><button aria-label={`Play ${v.title}`} className="absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-[#d9435c] shadow-[0_0_35px_rgba(217,67,92,.55)] transition group-hover:scale-110"><Play className="ml-1 h-6 w-6 fill-white"/></button><div className="absolute bottom-0 p-6"><h2 className="font-display text-xl font-black tracking-wider md:text-2xl">{v.title}</h2><p className="font-tech mt-2 text-xs tracking-[0.25em] text-[#8ab1b9]">{v.meta}</p></div></div></article>)}</div></main></>;
}

function TourPage() {
  return <><PageHero eyebrow="ON THE ROAD // 003" title="WORLD" accent="TOUR" description="#itriedcallingyou comes alive. Select a city and secure your access before the signal moves on." /><main className="relative mx-auto max-w-5xl px-5 py-20 md:px-8"><div className="mb-8 flex items-center gap-3 font-tech text-sm tracking-[0.3em] text-[#5c8a93]"><CalendarDays className="h-5 w-5"/> 2026 TOUR SCHEDULE</div>{TOUR.map(t=><div key={t.date+t.city} className="group flex flex-col gap-3 border-b border-white/10 px-3 py-6 transition hover:bg-white/[0.03] sm:flex-row sm:items-center sm:gap-6"><span className="w-24 shrink-0 font-display text-xl font-black text-[#d9435c]">{t.date}</span><span className="flex flex-1 items-center gap-2 font-display font-bold tracking-wider"><MapPin className="h-4 w-4 text-[#5c8a93]"/>{t.city}</span><span className="font-tech flex-1 text-sm text-white/50">{t.venue}</span><button className="inline-flex w-max items-center gap-2 border border-white/25 px-5 py-2.5 font-tech text-xs tracking-[0.25em] transition group-hover:border-[#d9435c] group-hover:text-[#d9435c]"><Ticket className="h-4 w-4"/>TICKETS</button></div>)}</main></>;
}

function MerchPage() {
  return <><PageHero eyebrow="SUPPLY DROP // 004" title="OFFICIAL" accent="MERCH" description="Limited-run pieces engineered for the #itriedcallingyou era. Built dark, marked in crimson." /><main className="mx-auto max-w-7xl px-5 py-20 md:px-8"><div className="grid gap-7 sm:grid-cols-2 lg:grid-cols-3">{MERCH.map((m,i)=><article key={m.name} className="group border border-white/10 bg-[#0b0b0f] transition hover:border-[#d9435c]/60"><div className="relative flex aspect-[4/5] items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_center,#28282e_0,#0b0b0f_63%)]"><div className={`absolute h-72 w-52 transition duration-500 group-hover:scale-105 ${i===0?'rounded-t-[70px] bg-[#151519]':'rounded-t-[90px] bg-[#101014]'}`}><div className="absolute left-1/2 top-24 w-max -translate-x-1/2 text-center"><TriangleMark size={54} className="mx-auto text-[#d9435c]"/><div className="font-tech mt-3 text-[10px] tracking-[0.3em] text-white/55">{m.mark}</div></div></div><Package className="absolute right-5 top-5 h-5 w-5 text-white/20"/></div><div className="flex items-center justify-between p-5"><div><h2 className="font-display text-sm font-bold tracking-wider">{m.name}</h2><p className="mt-2 font-display font-black text-[#d9435c]">{m.price}</p></div><button aria-label={`Add ${m.name} to bag`} className="border border-white/15 p-3 transition hover:border-[#d9435c] hover:text-[#d9435c]"><ShoppingBag className="h-5 w-5"/></button></div></article>)}</div></main></>;
}

function Footer() {
  return (
    <footer className="border-t border-white/8 py-12">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-7 px-5 md:px-8">
        <div className="flex w-full flex-col items-center justify-between gap-7 md:flex-row">
          <div className="flex items-center gap-3"><TriangleMark size={34} className="text-[#d9435c]"/><span className="font-display font-extrabold tracking-[0.18em]">BIG SKRILLA</span></div>
          <div className="flex gap-5 font-tech text-xs tracking-[0.2em] text-white/50"><a href="./music.html" className="hover:text-[#d9435c]">MUSIC</a><a href="./videos.html" className="hover:text-[#d9435c]">VIDEOS</a><a href="./tour.html" className="hover:text-[#d9435c]">TOUR</a></div>
          <p className="font-tech text-[11px] tracking-[0.2em] text-white/30">© 2026 BIG SKRILLA WORLD</p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-3 border-t border-white/8 pt-6 font-tech text-[10px] tracking-[0.18em] text-white/45">
          {SOCIAL_LINKS.map(link => (
            <a key={link.label} href={link.href} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-[#d9435c]">{link.label}</a>
          ))}
        </div>
      </div>
    </footer>
  );
}

export function App() {
  const page = (document.body.dataset.page || 'home') as PageName;
  const pageContent = { home: <HomePage />, music: <MusicPage />, videos: <VideosPage />, tour: <TourPage />, merch: <MerchPage /> }[page] || <HomePage />;
  return <div className="relative min-h-screen bg-[#050507] text-white"><GameLoader/><Header page={page}/>{pageContent}<Footer/></div>;
}

export default App;
